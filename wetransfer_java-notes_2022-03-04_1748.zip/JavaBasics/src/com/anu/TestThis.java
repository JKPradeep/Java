/**
 * 
 */
package com.anu;

/**
 * @author gowsh
 *
 */
public class TestThis {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		// TODO Auto-generated method stub

		ThisClass tc = new ThisClass();
		tc.display();
				
	
		
	}

}
