/**
 * 
 */
package com.anu;

/**

 *
 */
public class basicsPractice {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int a = 20;
		int b = 10;
		int c = a + b;

		System.out.println(c);

		boolean status;
		status = true;
		boolean newstatus = false;
		System.out.println("my old status was" + status);
		System.out.println("my new satus was" + newstatus);

		char i = 'd';
		char j = 'p';
		char f = 10;

		System.out.println("first char value is" + i);
		System.out.println("second char value is" + j);
		System.out.println("third char value is" + f);

		String name = "java practice";

		System.out.println(name);
		System.out.println(name.length());
		System.out.println(name.startsWith(name));
		System.out.println(name.startsWith("java"));
		System.out.println(name.charAt(3));
		System.out.println(name.toUpperCase());

		int m = 50;
		int n = 100;

		if (m > n)

			System.out.println("m greater than n");

		else if (m < n)

			System.out.println("m less than n");

		else if (m == n)

			System.out.println("m less than n");

		else if ((m == 0) && (n == 1))

			System.out.println("false");

		else if ((m == 0) || (n == 0))

			System.out.println("false");

		for (int q = 1; q <= 25; q++) {
			System.out.println("for loop" + q);

		}

		for (int q = 1; q <= 10; q++) {
			for (n = 1; n <= 5; n++) {
				if (n == 2) {
					break;
				}

				System.out.println(q + "*" + n);
			}
		}

		int q = 1;

		while (q <= 10) {

			System.out.println("while loop" + q);
			q++;
		}

		int p = 7;

		switch (p) {

		case 1:
			System.out.println("monday");
			break;

		case 3:
			System.out.println("tuesday");
			break;

		case 7:
			System.out.println("wednesday");
			break;

		default:
			System.out.println("sunday");
		}

		int x = 20;
		p = 40;
		String st = (x <= p) ? "p is larger " : "x is small or equal ";
		{
			System.out.println("condition is " + st);
		}

		int marks = 70;
		String result = (marks > 60) ? "pass" : "fail ";
		{
			System.out.println(" result is" + result);
		}

	}
}
