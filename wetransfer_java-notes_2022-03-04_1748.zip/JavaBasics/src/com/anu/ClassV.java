/**
 * 
 */
package com.anu;

/**
 * @author gowsh
 *
 */
public class ClassV{
	

	public static void main(String[] args) {
		
		
		ClassVmain vc1 = new ClassVmain();
		{	
		System.out.println(vc1.a);
		System.out.println(vc1.g);
		
		}
			
		
		ClassVmain vc2 = new ClassVmain();
		
		{
			System.out.println(vc2.a);
			System.out.println(vc2.g);
		}

	}
 
}
