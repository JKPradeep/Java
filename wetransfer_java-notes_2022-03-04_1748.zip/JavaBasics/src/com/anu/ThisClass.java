/**
 * 
 */
package com.anu;

/**
 * @author gowsh
 *
 */
public class ThisClass {
	
	int Rollno;
	String name;
	
   void display()
   
	{
		Rollno=60;
		name="tanu";
		
		System.out.println(this.name);
		System.out.println(this.Rollno);
	}

   
	  
      
}
	


