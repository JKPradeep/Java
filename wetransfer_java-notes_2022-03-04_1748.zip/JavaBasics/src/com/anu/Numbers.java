/**
 * 
 */
package com.anu;

/**
 * @author gowsh
 *
 */
public class Numbers
{

	int x=50;
	int y= 30;

	public static void main(String[] args) {
		
	System.out.println("program started");
		
	Numbers no1 = new Numbers();
		no1.sum();
		System.out.println(no1.x);
		System.out.println(no1.y);
		System.out.println("program ended");
	Numbers no2 = new Numbers();
		no2.sum();
		System.out.println(no2.x);
		System.out.println(no2.y);
		System.out.println("program ended");
		
	
	}
    
	    public void sum()
     
	    {
    	  int a=50;
    	  int b=30;
    	  int c=a+b;
    	  
    	 System.out.println("sum of numers is"+c);
    	 
	    }	 
    	  
      }
      

