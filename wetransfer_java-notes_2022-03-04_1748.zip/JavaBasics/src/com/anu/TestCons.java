/**
 * 
 */
package com.anu;

/**
 * @author gowsh
 *
 */
public class TestCons {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ConsClass cc = new ConsClass();
		cc.display();
		
	}

}
