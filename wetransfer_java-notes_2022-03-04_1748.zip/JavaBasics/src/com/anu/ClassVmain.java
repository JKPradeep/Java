/**
 * 
 */
package com.anu;

/**
 * @author gowsh
 *
 */
public class ClassVmain {

	int a = 30;

	int g = 80;

	static int b = 60;

	final static String NUMBERS = "alphabets";

	
	public static void main(String[] args) {

		int c = 90;
		{
			System.out.println(c);
		}

		{
			System.out.println(ClassVmain.b);
		}
		

		System.out.println(ClassVmain.NUMBERS);

	}
     static {System.out.println("alphabets have values");
     }
	
	
	
	

     
}


