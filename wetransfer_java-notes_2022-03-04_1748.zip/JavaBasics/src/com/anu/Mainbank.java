/**
 * 
 */
package com.anu;

/**
 * @author gowsh
 *
 */
public class Mainbank {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Banking cos1 = new Banking();

		cos1.setName("sri");
		cos1.setEmailId("siri123@gmail.com");
		cos1.setPhoneno(9498626);
		cos1.setAdharno(87379084);

		System.out.println("customer 1" + cos1);

		System.out.println("customer 1" + cos1.getName());

		Banking cos2 = new Banking();
		
		cos2.setName("anu");
		cos2.setPhoneno(88599388);
		cos2.setEmailId("anu.20@gmail.com");

		System.out.println("customer2" + cos2.getPhoneno());

		System.out.println("customer 2" + cos2.getName());

	}
}
