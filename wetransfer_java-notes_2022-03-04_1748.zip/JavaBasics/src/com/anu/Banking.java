/**
 * 
 */
package com.anu;

/**
 * @author gowsh
 *
 */
public class Banking {

	private String name;

	private double phoneno;

	private String emailId;

	private double Adharno;

	

	public void open() {
		System.out.println("open account ");

	}

	public void login() {
		System.out.println("login online account");
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPhoneno() {
		return phoneno;
	}

	public void setPhoneno(double phoneno) {
		this.phoneno = phoneno;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public double getAdharno() {
		return Adharno;
	}

	public void setAdharno(double adharno) {
		Adharno = adharno;
	}
	
	

}
