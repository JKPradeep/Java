/**
 * 
 */
package com.anu;

/**
 * @author gowsh
 *
 */
public class ConsClass {
	 int a;
	 String name;
	
	 void display()
	
	 {
		 System.out.println(a);
		 System.out.println(name);
	 }
	 
	 

}
