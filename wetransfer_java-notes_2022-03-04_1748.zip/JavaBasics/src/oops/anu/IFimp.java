package oops.anu;

public class IFimp  implements IF1,IF2,IF3,IF4{
	
	public void sing()
	{
		System.out.println("singing");
		
	}
public void dance() {
	System.out.println("dancing");
}
	
	public void read() {
		System.out.println("reading");
	}

	public void play() {
	System.out.println("playing");
	
	}
}
