package oops.anu;

public interface IF4 {
	
	void play();

}
