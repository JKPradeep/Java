package oops.anu;

public abstract class Abstract2 extends Abstract1{

	@Override
	void sing() {
		// TODO Auto-generated method stub
		System.out.println("singing");
	}

	@Override
	void dance() {
		// TODO Auto-generated method stub
		System.out.println("dancing");
	}

	@Override
	void read() {
		// TODO Auto-generated method stub
		System.out.println("reading");
	}

	@Override
	void play() {
		// TODO Auto-generated method stub
		System.out.println("playing");
	}
	
	

	
}
