/**
 * 
 */
package oops.anu;

/**
 * @author gowsh
 *
 */
public class AbstractMain {

	public static void main(String[] args) {
		

	Abstract1 a1 = new Abstarct2();
	a1.play();
	a1.read();
	a1.read();
	a1.sing();
	}

}
