package oops.anu;

public  abstract class Abstract1 {
  
	abstract void sing();
   
	abstract void dance();
	
	abstract void read();
	
	abstract void play();
	
}
