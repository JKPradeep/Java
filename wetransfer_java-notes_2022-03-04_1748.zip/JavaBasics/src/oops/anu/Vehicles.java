/**
 * 
 */
package oops.anu;

/**
 * @author gowsh
 *
 */
public class Vehicles {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Bike4 bk = new Bike4();
		
		System.out.println(bk.wheels);
		bk.ch1();
		
		System.out.println(bk.wh);
		bk.gp();
		 
		System.out.println(bk.wheels);
		bk.p();
		
		
		
		Car2 p = new Bus3();
		
		System.out.println(p.wh);
		
		System.out.println(p.wheels);
		
		p.gp();
	
		
	}

}
