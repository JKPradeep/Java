package oops.anu;

public interface IF3 {
	
	void read();

}
