package oops.anu;

public interface IF2 {
	
	void dance();

}
