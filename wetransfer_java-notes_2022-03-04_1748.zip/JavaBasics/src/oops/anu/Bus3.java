package oops.anu;

public class Bus3 extends Car2 {
 
	int whe = 6;
 
 public void ch2()
 {
	 System.out.println("child2");
	 System.out.println(super.wheels);
	 super.p();
	
 }
}
