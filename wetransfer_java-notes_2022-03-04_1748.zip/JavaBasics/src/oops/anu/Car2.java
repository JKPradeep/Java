/**
 * 
 */
package oops.anu;

/**
 * @author gowsh
 *
 */
public class Car2 extends jeep1 {
	
	int wheels= 4;
	
	public void p ()
	{
		System.out.println("parent class");
	}

}
