package oops.anu;

public interface IF1 {
	
	void sing(); 

}
