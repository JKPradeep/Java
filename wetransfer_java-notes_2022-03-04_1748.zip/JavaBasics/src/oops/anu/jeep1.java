package oops.anu;

public class jeep1 {
 
	int wh = 8;
 
	public void gp()
	{
		System.out.println("grand parent");
	}
	
}
