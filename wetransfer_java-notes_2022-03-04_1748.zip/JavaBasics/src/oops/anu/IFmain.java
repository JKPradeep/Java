/**
 * 
 */
package oops.anu;

/**
 * @author gowsh
 *
 */
public class IFmain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		IFimp hob = new IFimp();
		hob.dance();
		hob.sing();
		hob.read();
		hob.play();
				
	}

}
