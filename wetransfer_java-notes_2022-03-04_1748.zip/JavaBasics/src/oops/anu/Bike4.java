package oops.anu;

public class Bike4 extends Car2{
	
	int wheels= 2;
	
	public void ch1()
	{
		System.out.println("child1");
	}

}
