
public class dataTypeConversion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String balance = "1200";
		String depositAmt = "52";
		
		int newBalance;

		newBalance = Integer.parseInt(balance) + Integer.parseInt(depositAmt);
		
		System.out.println(newBalance);
		
		
//		String s = String.valueOf(newBalance);
		
	}

}
