package overloading;

public class A {
	
	// Method Overloading
	
	void add(int a, int b)
	{
		System.out.println("2 Parameters");
		System.out.println(a+b);
	}
	
	int add(int a, int b, int c)
	{
		System.out.println("3 Parameters");
		System.out.println(a+b+c);
		return a+b+c;
	}
	
	
	///////////////////
	
//	Operator Overloading
		int i = 5;
		int j = 6;
	

}
