package overloading;

public class OverloadingMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		A a  = new A();
		a.add(2, 4);

		a.add(7, 1, 2);
		
		
////////////////////
		
//		Operator Overloading	
		System.out.println("i+j : " + a.i + a.j);
		System.out.println("i+j : " + (a.i + a.j));
		
	}

}
