/**
 * 
 */

/**
 * @author gowsh
 *
 */

//Class
public class Student_21 {
	
//	properties
	private int rollNo;
	
	private String name;
	
	public int marks;
	
	private String emailId;
	
	private double phoneNo;
	
	
//	methods
	public void play()
	{
		System.out.println("Student Playing !!!!!");
	}
	
	public void read()
	{
		System.out.println("Student Reading !!!!!");
	}

	
	
	
//	Constructors - Non Parameterized & Parameterized Constructors
	public Student_21() {
		super();
	}

	public Student_21(int rollNo, String name, int marks, String emailId, double phoneNo) {
		super();
		this.rollNo = rollNo;
		this.name = name;
		this.marks = marks;
		this.emailId = emailId;
		this.phoneNo = phoneNo;
	}
	
	

//	Getters and Setters - methods
	public int getRollNo() {
		return rollNo;
	}

	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getMarks() {
		return marks;
	}

	public void setMarks(int marks) {
		this.marks = marks;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public double getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(double phoneNo) {
		this.phoneNo = phoneNo;
	}

	
//	toString() - System.out.println()
	@Override
	public String toString() {
		return "Student [rollNo=" + rollNo + ", name=" + name + ", marks=" + marks + ", emailId=" + emailId
				+ ", phoneNo=" + phoneNo + "]";
	}


}
