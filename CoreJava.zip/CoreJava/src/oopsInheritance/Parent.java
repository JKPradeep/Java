package oopsInheritance;

public class Parent extends GrandParent{

	int a = 20;
	
	void display() {
		System.out.println("Parent Display Method !!");
	}
}
