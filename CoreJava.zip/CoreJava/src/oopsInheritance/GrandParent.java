package oopsInheritance;

public class GrandParent {
	
	int x = 60;
	
	void sh()
	{
		System.out.println("sh - grand !!");
	}

}
