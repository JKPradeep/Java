package oopsInheritance;

public class Child1 extends Parent{
	
	int a = 40;  // Same Property - Child Overriding the Parent
	int b = 30;
	
	void show() {
		System.out.println("Child Show method !!");
	}

}
