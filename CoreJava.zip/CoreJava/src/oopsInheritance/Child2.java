package oopsInheritance;

public class Child2 extends Parent {

	int b = 30;

	void show() {
		System.out.println("Child Show method !!");
	}

}

