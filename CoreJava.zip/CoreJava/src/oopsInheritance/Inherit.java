package oopsInheritance;

public class Inherit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Child1 c1 = new Child1();

		System.out.println(c1.b);
		c1.show();

		System.out.println(c1.a); // How to Access Parent Class 'a' Value??? using super keyword
		c1.display();

		System.out.println(c1.x);
		c1.sh();

		/////////////////////////////////
		
		Child2 c2 = new Child2();
		
		System.out.println(c2.b);
		c2.show();

		System.out.println(c2.a);
		c2.display();

		System.out.println(c2.x);
		c2.sh();

		
		////////////////////
		
		Parent p = new Child2();  	// *****Important*****//
		System.out.println(p.a);
		System.out.println(p.x);

		
	}

}
