/**
 * 
 */

/**
 * @author gowsh
 *
 */
public class Variables_4 {

	int i = 10; // instance variables - Outside a method - Object to be Created
	static int s = 20; // static variables- static keyword for instance variable -
						// static : Sharing memory allocation - ClassName.varName

	public static void main(String[] args) {

		int l = 30; // local variables - Inside a method - Directly accessible
		
		System.out.println(l);
		
		System.out.println(Variables_4.s);
		
		Variables_4 v = new Variables_4();
		System.out.println(v.i);
		

	}

}
