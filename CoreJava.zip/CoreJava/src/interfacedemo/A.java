package interfacedemo;

public interface A {
	
	void aDisplay();

}
