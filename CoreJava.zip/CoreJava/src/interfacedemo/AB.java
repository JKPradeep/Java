package interfacedemo;

// We can implements multiple interfaces, but can extends only one Class
//	public class AB implements A,B{


public class AB extends C implements A,B{

	@Override
	public void bDisplay() {
		// TODO Auto-generated method stub
		System.out.println("bDiplaying !!!");
	}

	@Override
	public void aDisplay() {
		// TODO Auto-generated method stub
		System.out.println("aDiplaying !!!");
	}

	
}
