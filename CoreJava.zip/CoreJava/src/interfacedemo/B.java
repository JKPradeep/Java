package interfacedemo;

public interface B {
	
	void bDisplay();

}
