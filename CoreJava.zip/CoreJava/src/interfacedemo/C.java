package interfacedemo;

public class C {
	
	public void cDisplay() {
		System.out.println("cDiplaying !!!");
	}

}
