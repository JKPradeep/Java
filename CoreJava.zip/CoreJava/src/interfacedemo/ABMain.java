package interfacedemo;

public class ABMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

//		We can't instantize interface new InterfaceName(); 
		
		AB obj = new AB();
		obj.aDisplay();
		obj.bDisplay();
		
		obj.cDisplay();
			
	}

}
