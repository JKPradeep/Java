package overrding;

public class A {
	
	void display() {
		System.out.println("A  method !!!");
	}

}
