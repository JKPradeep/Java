package overrding;

public class B extends A{
	
	void display() {
		System.out.println("B method !!!");
	}

	
	
//	parent method can be overriding in child -- method overriding
	
}
