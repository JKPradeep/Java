package overrding;

public class OverrideMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Method Overriding
		B b = new B();
		b.display();
		
	}

}
