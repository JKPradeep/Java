package genericsDemo;

public class Student {

}
