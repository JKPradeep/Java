 /**
 * 
 */


/**
 * @author gowsh
 *
 */
public class Basics_1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Hi Anu");

//		DataTypes
		
//		Type varName = varValue;
		
//		Primitive 
		int a = 20;
		
		double d = 89.9;
		
		char c = 'g';
		
		boolean f = true;
		
		
//		Non Primitive
		String name = "Anupama";
		
		
		System.out.println("My Name is " + name);   
		
		System.out.println("2nd Character is " + name.charAt(2)); // Index - starts from 0
		
		System.out.println("Length is " + name.length());  		// No. of Characters (Includes Space also)
		
		System.out.println(name.endsWith("pama"));
	
		System.out.println(name.toLowerCase());
		
		System.out.println(name.toUpperCase());
		
		
		
//		Conditions : if - else if - else
//		Operators   :  <  >  <=  >=  ==  !=
//		&&  ||   
		
//		&& - All True ==> True
		System.out.println("Operator AND "+ (true && true));
		
//		|| - Any one is True ==> True
		System.out.println("Operator OR "+ (true || false));
		
		
		
		int m = -300;
		int n = -300;
		
		if(m > n)
		{
			System.out.println("m more than n");
		}
		else if(m < n)
		{
			System.out.println("m less than n");
		}
		else if((m == 0) && (n==0))
		{
			System.out.println("m greater than 0");
		}
		else if(m != 0)                          // Single Line Statements in the BLOCK is not required { }
			System.out.println("m greater than 0");
		
		else
		{
			System.out.println("m n Both are Equal");
		}
		
	
		
		
//		Ternary Operator - single line if else statement
		
		int p =1000;
		int q =200;
		
		if(p>q)
		{
			System.out.println("--- p is greater");
		}
		else
		{
			System.out.println("---- p is lesser or Equal");
		}
//	var v= ? true:false	
	    String st = (p>q) ? "p is greater" : "p is lesser or Equal";
		System.out.println(st);
		
		
		
		
		//		switch case
		
		int h = 3; 
		
		switch(h) 
		{
			case 0:
				System.out.println("Case 0 Printing");
				break;
			case 1:
				System.out.println("Case 1 Printing");
				break;
			case 2:
				System.out.println("Case 2 Printing");
				break;
			case 3:
				System.out.println("Case 3 Printing");
				
				break;
			default:
				System.out.println("Default case Printing");
		}
		
		
		
		
//		Loops 
		
//		for loop
//		for(initializer; condition; increment)
		for(int i=1; i<=20; i++) {
			System.out.println("For Loop Statement "+ i);
		}
		
		
//		while loop
		int j=1;
		while(j<=20) {
			System.out.println("While Loop Statement "+ j);
			j++;
		}
		
		
		
//		Nested for Loop	
		for(int i=0; i<5; i++)
		{
			for(j=0; j<4; j++)
			{
				System.out.println(i+ " " +j);
			}
		}
		
		
//		break - stop
		for(int i=0; i<5; i++)
		{
			if(i==3)
			{
				break;
			}
			System.out.println(i);
		}
		
		
		
		System.out.println("======");
		
//		continue - skip
		for(int i=0; i<5; i++)
		{
			if(i==3)
			{
				continue;
			}
			System.out.println(i);
		}
		
		
	
		
		
		
	}

}
