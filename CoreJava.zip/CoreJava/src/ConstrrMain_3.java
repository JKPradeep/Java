/**
 * 
 */

/**
 * @author gowsh
 *
 */
public class ConstrrMain_3 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		Constrr_Student_31 std = new Constrr_Student_31();  // Non Parameterized - default constructor
		System.out.println(std.rollNo);		// int  : 0  when value is not assigned
		System.out.println(std.name);		// String : null when value is not assigned
		
		
		Constrr_Student_31 std2 = new Constrr_Student_31(23, "Anu");  // Parameterized 
		System.out.println(std2.rollNo);		
		System.out.println(std2.name);
		
	}

}
