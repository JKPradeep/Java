
public class ThisKeywordDemo {

	int a = 10;
	
	void display()
	{
		int a = 20;
		System.out.println(a);   		// 20  - local variable
		System.out.println(this.a);    // 10 - this. --> refers to instance Variable
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ThisKeywordDemo th = new ThisKeywordDemo();
		th.display();

	}

}
