package calci;

public class CalciMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
//		CalciImpl c = new CalciImpl();

		Calci c = new CalciImpl();
		
		System.out.println(c.add(2, 7));
		System.out.println(c.sub(7, 3));
		System.out.println(c.multiply(4, 5));
		System.out.println(c.divison(6, 3));
		
		
	}

}
