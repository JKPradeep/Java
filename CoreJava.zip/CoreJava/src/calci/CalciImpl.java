package calci;

public class CalciImpl implements Calci{

	@Override
	public int add(int a, int b) {
		// TODO Auto-generated method stub
		int c = a+b;
		return c;
	}

	@Override
	public int sub(int a, int b) {
		// TODO Auto-generated method stub
		int c = a-b;
		return c;
	}

	@Override
	public int multiply(int a, int b) {
		// TODO Auto-generated method stub
		int c = a*b;
		return c;
	}

	@Override
	public int divison(int a, int b) {
		// TODO Auto-generated method stub
		int c = a/b;
		return c;
	}
	
	
	

}
