
/**
 * 
 */

/**
 * @author gowsh
 *
 */
public class StudentMain_2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

//		Object creation 
		Student_21 std1 = new Student_21(); 
		
//		public - marks property

		std1.marks = 40;
		
//		private - remaining all properties
//		data setting
		std1.setRollNo(1);
		std1.setName("Anupama");
//		std1.setMarks(90);
		std1.setEmailId("anu@gmail.com");
		std1.setPhoneNo(3453453);

		System.out.println("Student1 " + std1);
		// std1.toString()

//		retrieve
		System.out.println("Student1 " + std1.getEmailId());
	
//		method calling
		std1.play();
		std1.read();
		

		
		Student_21 std2 = new Student_21(); 
		
		std2.setRollNo(2);
		std2.setName("Gowshik");
		std2.setMarks(10);
		std2.setEmailId("gow@gmail.com");
		std2.setPhoneNo(8876776);

		System.out.println("Student2 " + std2);

		System.out.println("Student2 " + std2.getEmailId());
	
		std2.play();
		std2.read();
		
	}

}
