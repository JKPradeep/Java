/**
 * 
 */

/**
 * @author gowsh
 *
 */
public class Constrr_Student_31 {
	
	public int rollNo;
	
	public String name;

//	public Constrr_Student_31(int rollNo, String name) {
//		super();
//		this.rollNo = rollNo;
//		this.name = name;
//	}
	
	
	
	public Constrr_Student_31(int rNo, String sname) {
		super();
		rollNo = rNo;
		name = sname;
	}

	public Constrr_Student_31() {
		super();
	}

	
//	Constructor: No return Type & ConstructorName is same as ClassName
	

}
