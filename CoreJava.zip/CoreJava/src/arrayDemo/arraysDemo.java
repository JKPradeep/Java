package arrayDemo;

public class arraysDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		int m; 	// declaration
		m = 10; // initialization
		
		int a = 10;   // declaration and initialization
		int b = 20;
		int c = 30;
		int d = 40;
		int e = 50;
		
//		Array:  1. All Datatype should be Same   2. Size is Fixed  3. Index starts from 0
		
//		All DataTypes : int
//		Total No. of int variables : 5
		
		int[] ar = {10, 20, 30, 40, 50}; // declaration and initialization
		
		int[] ary = new int[5]; // declaration and instantiation
		ary[0] = 10;
		ary[1] = 20;
		ary[2] = 30;
		ary[3] = 40;
		ary[4] = 50;

//		ary[5] = 60;   // ArrayOutOfException
		
		
		for (int i=0; i<ary.length; i++)
		{
			System.out.println(ary[i]);
		}

		
		System.out.println(ary);  //Address object Location
		
		
		// for each is preferable
		
		for (int v : ar)
		{
			System.out.println(v);
		}
		
	}

}
