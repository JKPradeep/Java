package abstractDemo;

public abstract class A {
	
	public abstract void display();
	
	public void show() {
		System.out.println("Showing !!!");
	}
}

