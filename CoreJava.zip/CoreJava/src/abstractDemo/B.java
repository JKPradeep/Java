package abstractDemo;

public abstract class B extends A {

	@Override
	public void display() {
		System.out.println("Displaying !!!");
		

	}
	
	public abstract void read();

}
