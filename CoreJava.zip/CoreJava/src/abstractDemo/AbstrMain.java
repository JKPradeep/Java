package abstractDemo;

public class AbstrMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		C c =  new C();
		c.read();
		c.display();
		c.show();

	}

}
