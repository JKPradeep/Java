package abstractDemo;

public class C extends B{

	@Override
	public void read() {
		System.out.println("Reading !!!");
		
	}

}
