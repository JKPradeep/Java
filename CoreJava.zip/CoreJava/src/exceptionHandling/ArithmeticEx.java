package exceptionHandling;

public class ArithmeticEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a = 4;
//		int b = 2;
		int b = 0;

		try {
			int c = a / b;
			System.out.println(c);
		} catch (Exception e) {
			System.out.println(e);
		}
		


		
		int d = 8;
		int e = 9;
		int f = d + e;
		System.out.println("Anupama" + f);

	}

}
