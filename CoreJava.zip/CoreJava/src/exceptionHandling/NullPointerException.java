package exceptionHandling;

public class NullPointerException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String name = "Anumpama";
		
//		String name = "";
		
//		String name = null;
		
		try {
			int l = name.length();
			System.out.println(l);
			System.out.println("In Try Block");
		}
		catch(Exception e) {
			System.out.println(e);
			System.out.println("In catch Block");
		}
		
		System.out.println("Ended");
	}

}
