package exceptionHandling;

public class IndexOutOfBoundExcpn {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] ary = new int[5]; // declaration and instantiation
		
		try {
			ary[0] = 10;
			ary[1] = 20;
			ary[2] = 30;
			ary[3] = 40;
			ary[4] = 50;
	
			ary[5] = 60;   // ArrayOutOfException
		}
		catch(Exception e) {
			System.out.println(e);
		}
		
		System.out.println("Ending");
	}

}
