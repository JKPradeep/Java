package exceptionHandling;

public class NumberFormatExcpn {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String name = "Anupa";
		String amt = "430";
		
		try {
			int i = Integer.parseInt(name);
			System.out.println(i);
			System.out.println("inside try block");
		}
		catch(Exception e)
		{
			System.out.println(e);
			System.out.println("inside catch block");
		}
		
		System.out.println("eNDED");
		

	}

}
