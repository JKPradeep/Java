/**
 * 
 */

/**
 * @author gowsh
 *
 */
public class StaticDemo_6 {

	/**
	 * @param args
	 */
	
	static int a = 10;
	
	
	static void display() {
		System.out.println("Diplaying - static method");
	}
	
	
//	static
//	{
//		System.out.println("Static Block");
//	}
	

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println(StaticDemo_6.a);   // className.varName
		
		StaticDemo_6.display();				 // className.method()
	}

}
