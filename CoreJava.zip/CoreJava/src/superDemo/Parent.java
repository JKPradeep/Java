package superDemo;

public class Parent {
	
	int a = 20;
	
		
	void display() {
		System.out.println("Display Parent Method!!");
	}

	Parent(){
		System.out.println("Parent Constructor");
	}
	
}
