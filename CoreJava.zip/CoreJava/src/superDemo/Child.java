package superDemo;

public class Child extends Parent{

	int a = 40;
	
	void display() {
		System.out.println("Display Child Method!!");
		System.out.println(a);
		System.out.println(super.a);  	// Immediate Parent Class Variables / Methods / Constructors
		super.display();
	}
	
	Child(){
		System.out.println("Child Constr");
	}
	
	//super()   //** Implicitly Executed by JVM **//
	
	// We should use super keyword in Child Classes only
	
}
