package superDemo;

public class MainSuper {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Child c =  new Child();
		c.display();	
	}

}
