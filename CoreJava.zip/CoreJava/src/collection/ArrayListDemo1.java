package collection;

import java.util.ArrayList;

public class ArrayListDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList<Integer> l = new ArrayList<Integer>();
		l.add(1);
		l.add(1019);
        l.add(203);
        System.out.println(l);
		
        // foreach
        for(Integer v  : l)
        {
        	System.out.println(v);
        }
		
	}

}
