package collection;

import java.util.ArrayList;

public class ArrayListDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList l = new ArrayList();
		l.add(1);
		l.add(1019);
        l.add(203);
//        l.add("Pradeep");
        System.out.println(l);
		
        
        
//        for(int i=0; i<l.size(); i++)
//        {
//        	System.out.println(l[i]);
//        }
		
        
        
        
	}

}
