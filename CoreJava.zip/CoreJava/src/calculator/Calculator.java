package calculator;

public abstract class Calculator {
	
	abstract int add(int a, int b);
	
	abstract int sub(int a, int b);
	
	abstract int multiply(int a, int b);
	
	abstract int divison(int a, int b);

}
