package calculator;

// Concrete class -- All methods in 100% Abstract Class / Interface. That Implementation class is called Concrete Class

public class CalculatorImpl extends Calculator{

	@Override
	int add(int a, int b) {
		// TODO Auto-generated method stub
		int c = a+b;
		return c;
	}

	@Override
	int sub(int a, int b) {
		// TODO Auto-generated method stub
		int c = a-b;
		return c;
	}

	@Override
	int multiply(int a, int b) {
		// TODO Auto-generated method stub
		int c = a*b;
		return c;
	}

	@Override
	int divison(int a, int b) {
		// TODO Auto-generated method stub
		int c = a/b;
		return c;
	}

	
}
