package calculator;

public class CalcMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		CalculatorImpl ci =  new CalculatorImpl();
		
		System.out.println(ci.add(2, 7));
		System.out.println(ci.sub(7, 3));
		System.out.println(ci.multiply(4, 5));
		System.out.println(ci.divison(6, 3));
	}

}
