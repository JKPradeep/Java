/**
 * 
 */

/**
 * @author gowsh
 *
 */
public class Variables_final_5 {

	final static String SCHOOLNAME = "SriChaitanya"; // final : Capital letters and can't assign any other value

	static String CollegeName = "Narayana";

	public static void main(String[] args) {

//		SCHOOLNAME = "DPS";  - Not possible
		CollegeName = "Sasi";
		

		System.out.println(Variables_final_5.SCHOOLNAME);
		System.out.println(Variables_final_5.CollegeName);
	}

}
